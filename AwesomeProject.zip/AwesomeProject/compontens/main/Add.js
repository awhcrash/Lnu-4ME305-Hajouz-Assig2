import { async } from '@firebase/util';
import { Camera, CameraType } from 'expo-camera';
import { useState } from 'react';
import { Button, StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

import { Stack, IconButton } from "@react-native-material/core";
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'


export default function Add( {navigation} ) {
  const [type, setType] = useState(CameraType.back);
  const [camera, setCamera] = useState(null);
  const [image, setImage] = useState(null);
  const [permission, requestPermission] = Camera.useCameraPermissions();

  if (!permission) {
    // Camera permissions are still loading
    return <View />;
  }

  if (!permission.granted) {
    // Camera permissions are not granted yet
    return (
      <View style={styles.container}>
        <Text style={{ textAlign: 'center' }}>We need your permission to show the camera</Text>
        <Button onPress={requestPermission} title="grant permission" />
      </View>
    );
  }

  const takePicture = async () => {
    if(camera){ //if camera exist & popt something
        const data = await camera.takePictureAsync(null)
        //console.log(data.uri)  //get the uri of the picture
        setImage(data.uri)
    }
  }

  function toggleCameraType() {
    setType(current => (current === CameraType.back ? CameraType.front : CameraType.back));
  }

  const pickImage = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result);

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  return (
    <View style={styles.container}>
      <Camera ref={ref => setCamera(ref)} style={styles.camera} type={type} >
        <View style={styles.buttonContainer}>



            {/* if the image exist it will show the tag uri */}
          {image && <Image source={{uri: image}} style={{flex: 3, aspectRatio: 1, margin: 0}}/> } 
            

            {/* Take Picture */}
        <TouchableOpacity style={styles.button} >
        <IconButton style={styles.icon} icon={props => <Icon name="camera-outline" style={styles.icon}/>}  onPress={() => takePicture()} />
          </TouchableOpacity>


            {/* Flip Camera */}
          <TouchableOpacity style={styles.button}>
          <IconButton  icon={props => <Icon name="camera-flip-outline" style={styles.icon}/>}  onPress={toggleCameraType} />
          </TouchableOpacity>

            {/* Save Picture */}
          <TouchableOpacity style={styles.button}>
          <IconButton  icon={props => <Icon name="content-save" style={styles.save}/>}  onPress={() => navigation.navigate('Save', {image})} />
          </TouchableOpacity>


          <Button  title="Camera roll" onPress={pickImage} />


        </View>
      </Camera>
    </View>
  );
}

const styles = StyleSheet.create({

    save: {
        //flex: 0,
        size: '45', 
        color:"green",
      },
    icon: {
        //flex: 0,
        size: '45', 
        color:"red",
        //flexDirection: 'row',
        //alignSelf: 'flex-end',
      },
      button: {
        flex: 3,
        alignSelf: 'flex-end',
        alignItems: 'center',
        //backgroundColor: 'black',
      },

    
  container: {
    flex: 2,
    justifyContent: 'left',
  },
  camera: {
    flex: 2,
  },
  buttonContainer: {
    //flex: 1,
    flexDirection: 'row',
    backgroundColor: 'transparent', //transparent
    margin: 3,
  },
  
  
  text: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
});
